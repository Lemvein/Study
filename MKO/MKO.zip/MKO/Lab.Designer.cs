﻿namespace MKO
{
    partial class Lab
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Lab));
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle7 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle8 = new DataGridViewCellStyle();
            Title1 = new Label();
            textBox1 = new TextBox();
            Matrix = new DataGridView();
            AK = new DataGridViewTextBoxColumn();
            K1 = new DataGridViewTextBoxColumn();
            K2 = new DataGridViewTextBoxColumn();
            K3 = new DataGridViewTextBoxColumn();
            K4 = new DataGridViewTextBoxColumn();
            labelQ1 = new Label();
            domainUpDown1 = new DomainUpDown();
            panel1 = new Panel();
            buttonNext1 = new Button();
            text2 = new TextBox();
            labelT1 = new Label();
            panel2 = new Panel();
            radioButton2 = new RadioButton();
            radioButton1 = new RadioButton();
            button1 = new Button();
            system44 = new TextBox();
            system43 = new TextBox();
            system42 = new TextBox();
            system41 = new TextBox();
            label3 = new Label();
            domainUpDown4 = new DomainUpDown();
            system34 = new TextBox();
            system24 = new TextBox();
            system33 = new TextBox();
            system14 = new TextBox();
            system32 = new TextBox();
            system23 = new TextBox();
            system31 = new TextBox();
            system13 = new TextBox();
            label2 = new Label();
            domainUpDown3 = new DomainUpDown();
            system22 = new TextBox();
            system12 = new TextBox();
            system21 = new TextBox();
            system11 = new TextBox();
            label5 = new Label();
            domainUpDown2 = new DomainUpDown();
            label1 = new Label();
            buttonNext2 = new Button();
            panelMode1 = new Panel();
            label4 = new Label();
            panelMode2 = new Panel();
            label26 = new Label();
            label25 = new Label();
            domainUpDownMM2 = new DomainUpDown();
            textBox25 = new TextBox();
            textBox24 = new TextBox();
            domainUpDownKK2 = new DomainUpDown();
            label23 = new Label();
            label22 = new Label();
            labelAlg3 = new Label();
            textBox23 = new TextBox();
            textBox22 = new TextBox();
            domainUpDownKK = new DomainUpDown();
            label9 = new Label();
            buttonMode21 = new Button();
            domainUpDownMM = new DomainUpDown();
            label8 = new Label();
            labelAlg2 = new Label();
            label7 = new Label();
            pictureBoxGist = new PictureBox();
            label6 = new Label();
            labelAlg = new Label();
            label24 = new Label();
            buttonCheckM = new Button();
            panelMode3 = new Panel();
            radioButton10 = new RadioButton();
            radioButton9 = new RadioButton();
            radioButton8 = new RadioButton();
            radioButton7 = new RadioButton();
            label29 = new Label();
            label27 = new Label();
            label13 = new Label();
            MatrixNorm = new DataGridView();
            dataGridViewTextBoxColumn1 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn2 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn3 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn4 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn5 = new DataGridViewTextBoxColumn();
            label12 = new Label();
            button3Check = new Button();
            domainUpDownPM2 = new DomainUpDown();
            comboBoxNorm3 = new ComboBox();
            comboBoxNorm4 = new ComboBox();
            domainUpDownPM1 = new DomainUpDown();
            comboBoxNorm2 = new ComboBox();
            comboBoxNorm1 = new ComboBox();
            label10 = new Label();
            label11 = new Label();
            panelMode4 = new Panel();
            label18 = new Label();
            groupBox1 = new GroupBox();
            radioButton14 = new RadioButton();
            radioButton12 = new RadioButton();
            radioButton13 = new RadioButton();
            radioButton11 = new RadioButton();
            textBoxF4 = new TextBox();
            textBoxF3 = new TextBox();
            textBoxF2 = new TextBox();
            textBoxF1 = new TextBox();
            domainUpDownF = new DomainUpDown();
            MatrixNorm2 = new DataGridView();
            dataGridViewTextBoxColumn6 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn7 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn8 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn9 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn10 = new DataGridViewTextBoxColumn();
            label15 = new Label();
            radioButtonAdd = new RadioButton();
            radioButtonExtr = new RadioButton();
            pictureBoxAdd = new PictureBox();
            pictureBoxExtr = new PictureBox();
            pictureBoxMult = new PictureBox();
            radioButtonMult = new RadioButton();
            label14 = new Label();
            button4Check = new Button();
            label4Title = new Label();
            label16 = new Label();
            panelMode5 = new Panel();
            label20 = new Label();
            label17 = new Label();
            dataGridView1 = new DataGridView();
            dataGridViewTextBoxColumn11 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn12 = new DataGridViewTextBoxColumn();
            button2 = new Button();
            label19 = new Label();
            pictureBox1 = new PictureBox();
            toolTip1 = new ToolTip(components);
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)Matrix).BeginInit();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panelMode1.SuspendLayout();
            panelMode2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxGist).BeginInit();
            panelMode3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)MatrixNorm).BeginInit();
            panelMode4.SuspendLayout();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)MatrixNorm2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxAdd).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxExtr).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxMult).BeginInit();
            panelMode5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // Title1
            // 
            Title1.Dock = DockStyle.Top;
            Title1.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point);
            Title1.Location = new Point(0, 0);
            Title1.Name = "Title1";
            Title1.Size = new Size(1401, 30);
            Title1.TabIndex = 0;
            Title1.Text = "Постановка задачи многокритериальной оптимизации";
            Title1.TextAlign = ContentAlignment.TopCenter;
            // 
            // textBox1
            // 
            textBox1.BackColor = SystemColors.Window;
            textBox1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBox1.Location = new Point(33, 47);
            textBox1.Multiline = true;
            textBox1.Name = "textBox1";
            textBox1.ReadOnly = true;
            textBox1.Size = new Size(1334, 96);
            textBox1.TabIndex = 2;
            textBox1.Text = resources.GetString("textBox1.Text");
            // 
            // Matrix
            // 
            Matrix.AllowUserToAddRows = false;
            Matrix.AllowUserToDeleteRows = false;
            Matrix.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            Matrix.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            Matrix.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            Matrix.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            Matrix.Columns.AddRange(new DataGridViewColumn[] { AK, K1, K2, K3, K4 });
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            Matrix.DefaultCellStyle = dataGridViewCellStyle2;
            Matrix.EditMode = DataGridViewEditMode.EditOnEnter;
            Matrix.Location = new Point(369, 149);
            Matrix.Name = "Matrix";
            Matrix.RowTemplate.Height = 25;
            Matrix.Size = new Size(668, 132);
            Matrix.TabIndex = 3;
            // 
            // AK
            // 
            AK.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            AK.HeaderText = "Альтернативы/критерии";
            AK.Name = "AK";
            AK.Width = 211;
            // 
            // K1
            // 
            K1.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            K1.HeaderText = "Цена";
            K1.Name = "K1";
            K1.Width = 72;
            // 
            // K2
            // 
            K2.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            K2.HeaderText = "Площадь";
            K2.Name = "K2";
            K2.Width = 101;
            // 
            // K3
            // 
            K3.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            K3.HeaderText = "Расположение";
            K3.Name = "K3";
            K3.Width = 140;
            // 
            // K4
            // 
            K4.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            K4.HeaderText = "Качество";
            K4.Name = "K4";
            // 
            // labelQ1
            // 
            labelQ1.AutoSize = true;
            labelQ1.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            labelQ1.Location = new Point(496, 12);
            labelQ1.Name = "labelQ1";
            labelQ1.Size = new Size(292, 25);
            labelQ1.TabIndex = 0;
            labelQ1.Text = "Математическая модель задачи\r\n";
            // 
            // domainUpDown1
            // 
            domainUpDown1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            domainUpDown1.Items.Add("min");
            domainUpDown1.Items.Add("max");
            domainUpDown1.Location = new Point(414, 13);
            domainUpDown1.Name = "domainUpDown1";
            domainUpDown1.Size = new Size(53, 29);
            domainUpDown1.TabIndex = 5;
            domainUpDown1.Text = "-";
            domainUpDown1.Wrap = true;
            // 
            // panel1
            // 
            panel1.Controls.Add(buttonNext1);
            panel1.Controls.Add(text2);
            panel1.Controls.Add(labelT1);
            panel1.Location = new Point(19, 49);
            panel1.Name = "panel1";
            panel1.Size = new Size(354, 90);
            panel1.TabIndex = 0;
            // 
            // buttonNext1
            // 
            buttonNext1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            buttonNext1.Location = new Point(252, 51);
            buttonNext1.Name = "buttonNext1";
            buttonNext1.Size = new Size(96, 29);
            buttonNext1.TabIndex = 9;
            buttonNext1.Text = "Проверить";
            buttonNext1.UseVisualStyleBackColor = true;
            buttonNext1.Click += buttonNext1_Click;
            // 
            // text2
            // 
            text2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            text2.Location = new Point(90, 15);
            text2.Name = "text2";
            text2.Size = new Size(20, 29);
            text2.TabIndex = 1;
            // 
            // labelT1
            // 
            labelT1.AutoSize = true;
            labelT1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            labelT1.Location = new Point(4, 18);
            labelT1.Name = "labelT1";
            labelT1.Size = new Size(344, 21);
            labelT1.TabIndex = 0;
            labelT1.Text = "Это задача      -x критериальной оптимизации:";
            // 
            // panel2
            // 
            panel2.Controls.Add(radioButton2);
            panel2.Controls.Add(radioButton1);
            panel2.Controls.Add(button1);
            panel2.Controls.Add(system44);
            panel2.Controls.Add(system43);
            panel2.Controls.Add(system42);
            panel2.Controls.Add(system41);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(domainUpDown4);
            panel2.Controls.Add(system34);
            panel2.Controls.Add(system24);
            panel2.Controls.Add(system33);
            panel2.Controls.Add(system14);
            panel2.Controls.Add(system32);
            panel2.Controls.Add(system23);
            panel2.Controls.Add(system31);
            panel2.Controls.Add(system13);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(domainUpDown3);
            panel2.Controls.Add(system22);
            panel2.Controls.Add(system12);
            panel2.Controls.Add(system21);
            panel2.Controls.Add(system11);
            panel2.Controls.Add(label5);
            panel2.Controls.Add(domainUpDown2);
            panel2.Controls.Add(label1);
            panel2.Controls.Add(domainUpDown1);
            panel2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            panel2.Location = new Point(393, 49);
            panel2.Name = "panel2";
            panel2.Size = new Size(574, 237);
            panel2.TabIndex = 9;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new Point(17, 202);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(350, 25);
            radioButton2.TabIndex = 31;
            radioButton2.TabStop = true;
            radioButton2.Text = "Ограничения на переменные не существуют";
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Location = new Point(17, 178);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(329, 25);
            radioButton1.TabIndex = 30;
            radioButton1.TabStop = true;
            radioButton1.Text = "Ограничения на переменные существуют";
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            button1.Location = new Point(475, 200);
            button1.Name = "button1";
            button1.Size = new Size(96, 29);
            button1.TabIndex = 11;
            button1.Text = "Проверить";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // system44
            // 
            system44.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            system44.Location = new Point(309, 133);
            system44.Name = "system44";
            system44.Size = new Size(55, 29);
            system44.TabIndex = 29;
            // 
            // system43
            // 
            system43.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            system43.Location = new Point(223, 133);
            system43.Name = "system43";
            system43.Size = new Size(55, 29);
            system43.TabIndex = 28;
            // 
            // system42
            // 
            system42.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            system42.Location = new Point(136, 133);
            system42.Name = "system42";
            system42.Size = new Size(55, 29);
            system42.TabIndex = 27;
            // 
            // system41
            // 
            system41.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            system41.Location = new Point(49, 132);
            system41.Name = "system41";
            system41.Size = new Size(55, 29);
            system41.TabIndex = 25;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(14, 136);
            label3.Name = "label3";
            label3.Size = new Size(394, 21);
            label3.TabIndex = 26;
            label3.Text = "K4=               x1+               x2+               x3+               x4 →";
            // 
            // domainUpDown4
            // 
            domainUpDown4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            domainUpDown4.Items.Add("min");
            domainUpDown4.Items.Add("max");
            domainUpDown4.Location = new Point(414, 134);
            domainUpDown4.Name = "domainUpDown4";
            domainUpDown4.Size = new Size(53, 29);
            domainUpDown4.TabIndex = 24;
            domainUpDown4.Text = "-";
            domainUpDown4.Wrap = true;
            // 
            // system34
            // 
            system34.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            system34.Location = new Point(309, 93);
            system34.Name = "system34";
            system34.Size = new Size(55, 29);
            system34.TabIndex = 23;
            // 
            // system24
            // 
            system24.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            system24.Location = new Point(309, 52);
            system24.Name = "system24";
            system24.Size = new Size(55, 29);
            system24.TabIndex = 23;
            // 
            // system33
            // 
            system33.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            system33.Location = new Point(223, 93);
            system33.Name = "system33";
            system33.Size = new Size(55, 29);
            system33.TabIndex = 22;
            // 
            // system14
            // 
            system14.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            system14.Location = new Point(309, 12);
            system14.Name = "system14";
            system14.Size = new Size(55, 29);
            system14.TabIndex = 17;
            // 
            // system32
            // 
            system32.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            system32.Location = new Point(136, 93);
            system32.Name = "system32";
            system32.Size = new Size(55, 29);
            system32.TabIndex = 21;
            // 
            // system23
            // 
            system23.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            system23.Location = new Point(223, 52);
            system23.Name = "system23";
            system23.Size = new Size(55, 29);
            system23.TabIndex = 22;
            // 
            // system31
            // 
            system31.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            system31.Location = new Point(49, 92);
            system31.Name = "system31";
            system31.Size = new Size(55, 29);
            system31.TabIndex = 19;
            // 
            // system13
            // 
            system13.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            system13.Location = new Point(223, 12);
            system13.Name = "system13";
            system13.Size = new Size(55, 29);
            system13.TabIndex = 16;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(14, 96);
            label2.Name = "label2";
            label2.Size = new Size(394, 21);
            label2.TabIndex = 20;
            label2.Text = "K3=               x1+               x2+               x3+               x4 →";
            // 
            // domainUpDown3
            // 
            domainUpDown3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            domainUpDown3.Items.Add("min");
            domainUpDown3.Items.Add("max");
            domainUpDown3.Location = new Point(414, 94);
            domainUpDown3.Name = "domainUpDown3";
            domainUpDown3.Size = new Size(53, 29);
            domainUpDown3.TabIndex = 18;
            domainUpDown3.Text = "-";
            domainUpDown3.Wrap = true;
            // 
            // system22
            // 
            system22.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            system22.Location = new Point(136, 52);
            system22.Name = "system22";
            system22.Size = new Size(55, 29);
            system22.TabIndex = 21;
            // 
            // system12
            // 
            system12.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            system12.Location = new Point(136, 12);
            system12.Name = "system12";
            system12.Size = new Size(55, 29);
            system12.TabIndex = 15;
            // 
            // system21
            // 
            system21.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            system21.Location = new Point(49, 51);
            system21.Name = "system21";
            system21.Size = new Size(55, 29);
            system21.TabIndex = 19;
            // 
            // system11
            // 
            system11.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            system11.Location = new Point(49, 11);
            system11.Name = "system11";
            system11.Size = new Size(55, 29);
            system11.TabIndex = 10;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(14, 55);
            label5.Name = "label5";
            label5.Size = new Size(394, 21);
            label5.TabIndex = 20;
            label5.Text = "K2=               x1+               x2+               x3+               x4 →";
            // 
            // domainUpDown2
            // 
            domainUpDown2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            domainUpDown2.Items.Add("min");
            domainUpDown2.Items.Add("max");
            domainUpDown2.Location = new Point(414, 53);
            domainUpDown2.Name = "domainUpDown2";
            domainUpDown2.Size = new Size(53, 29);
            domainUpDown2.TabIndex = 18;
            domainUpDown2.Text = "-";
            domainUpDown2.Wrap = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(14, 15);
            label1.Name = "label1";
            label1.Size = new Size(394, 21);
            label1.TabIndex = 11;
            label1.Text = "K1=               x1+               x2+               x3+               x4 →";
            // 
            // buttonNext2
            // 
            buttonNext2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            buttonNext2.Location = new Point(1314, 776);
            buttonNext2.Name = "buttonNext2";
            buttonNext2.Size = new Size(75, 30);
            buttonNext2.TabIndex = 10;
            buttonNext2.Text = "Далее";
            buttonNext2.UseVisualStyleBackColor = true;
            buttonNext2.Visible = false;
            buttonNext2.Click += buttonNext2_CLick;
            // 
            // panelMode1
            // 
            panelMode1.Controls.Add(label4);
            panelMode1.Controls.Add(labelQ1);
            panelMode1.Controls.Add(panel2);
            panelMode1.Controls.Add(panel1);
            panelMode1.Location = new Point(61, 302);
            panelMode1.Name = "panelMode1";
            panelMode1.Size = new Size(1024, 426);
            panelMode1.TabIndex = 10;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(19, 314);
            label4.Name = "label4";
            label4.Size = new Size(554, 84);
            label4.TabIndex = 10;
            label4.Text = "Решим данную задачу тремя методами и сравним полученные результаты:\r\n1) Метод последовательных уступок\r\n2) Метод главного критерия\r\n3) Метода свертывания критериев";
            // 
            // panelMode2
            // 
            panelMode2.Controls.Add(label26);
            panelMode2.Controls.Add(label25);
            panelMode2.Controls.Add(domainUpDownMM2);
            panelMode2.Controls.Add(textBox25);
            panelMode2.Controls.Add(textBox24);
            panelMode2.Controls.Add(domainUpDownKK2);
            panelMode2.Controls.Add(label23);
            panelMode2.Controls.Add(label22);
            panelMode2.Controls.Add(labelAlg3);
            panelMode2.Controls.Add(textBox23);
            panelMode2.Controls.Add(textBox22);
            panelMode2.Controls.Add(domainUpDownKK);
            panelMode2.Controls.Add(label9);
            panelMode2.Controls.Add(buttonMode21);
            panelMode2.Controls.Add(domainUpDownMM);
            panelMode2.Controls.Add(label8);
            panelMode2.Controls.Add(labelAlg2);
            panelMode2.Controls.Add(label7);
            panelMode2.Controls.Add(pictureBoxGist);
            panelMode2.Controls.Add(label6);
            panelMode2.Controls.Add(labelAlg);
            panelMode2.Controls.Add(label24);
            panelMode2.Location = new Point(33, 342);
            panelMode2.Name = "panelMode2";
            panelMode2.Size = new Size(1273, 447);
            panelMode2.TabIndex = 10;
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            label26.Location = new Point(73, 379);
            label26.Name = "label26";
            label26.Size = new Size(1125, 25);
            label26.TabIndex = 21;
            label26.Text = "Результат: при решении поставленной задачи методом последовательных уступок наилучшей является альтернатива ";
            label26.Visible = false;
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label25.Location = new Point(19, 337);
            label25.Name = "label25";
            label25.Size = new Size(589, 21);
            label25.TabIndex = 20;
            label25.Text = "Выделите ячейку с наилучшим выбором в таблице и нажмите кнопку проверки.";
            label25.Visible = false;
            // 
            // domainUpDownMM2
            // 
            domainUpDownMM2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            domainUpDownMM2.Items.Add("min");
            domainUpDownMM2.Items.Add("max");
            domainUpDownMM2.Location = new Point(352, 300);
            domainUpDownMM2.Name = "domainUpDownMM2";
            domainUpDownMM2.Size = new Size(53, 29);
            domainUpDownMM2.TabIndex = 19;
            domainUpDownMM2.Text = "-";
            domainUpDownMM2.Visible = false;
            domainUpDownMM2.Wrap = true;
            // 
            // textBox25
            // 
            textBox25.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBox25.Location = new Point(559, 299);
            textBox25.Name = "textBox25";
            textBox25.Size = new Size(56, 29);
            textBox25.TabIndex = 18;
            textBox25.Visible = false;
            // 
            // textBox24
            // 
            textBox24.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBox24.Location = new Point(495, 299);
            textBox24.Name = "textBox24";
            textBox24.Size = new Size(56, 29);
            textBox24.TabIndex = 17;
            textBox24.Visible = false;
            // 
            // domainUpDownKK2
            // 
            domainUpDownKK2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            domainUpDownKK2.Items.Add("K1");
            domainUpDownKK2.Items.Add("K2");
            domainUpDownKK2.Items.Add("K3");
            domainUpDownKK2.Items.Add("K4");
            domainUpDownKK2.Location = new Point(265, 300);
            domainUpDownKK2.Name = "domainUpDownKK2";
            domainUpDownKK2.Size = new Size(53, 29);
            domainUpDownKK2.TabIndex = 16;
            domainUpDownKK2.Text = "-";
            domainUpDownKK2.Visible = false;
            domainUpDownKK2.Wrap = true;
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label23.Location = new Point(0, 268);
            label23.Name = "label23";
            label23.Size = new Size(477, 21);
            label23.TabIndex = 14;
            label23.Text = "6) Решается задача оптимизации третьего частного критерия";
            label23.Visible = false;
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label22.Location = new Point(20, 234);
            label22.Name = "label22";
            label22.Size = new Size(1121, 21);
            label22.TabIndex = 13;
            label22.Text = "Вычислите уступку по критерию \"Цены\" выбрав одно значение, максимально близкое к оптимальному и запишите в таблицу. Нажмите кнопку проверки.";
            label22.Visible = false;
            // 
            // labelAlg3
            // 
            labelAlg3.AutoSize = true;
            labelAlg3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            labelAlg3.Location = new Point(0, 200);
            labelAlg3.Name = "labelAlg3";
            labelAlg3.Size = new Size(435, 21);
            labelAlg3.TabIndex = 12;
            labelAlg3.Text = "5) Задать допустимые пределы изменения ΔK1 (уступка)";
            labelAlg3.Visible = false;
            // 
            // textBox23
            // 
            textBox23.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBox23.Location = new Point(557, 139);
            textBox23.Name = "textBox23";
            textBox23.Size = new Size(56, 29);
            textBox23.TabIndex = 11;
            textBox23.Visible = false;
            // 
            // textBox22
            // 
            textBox22.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBox22.Location = new Point(495, 139);
            textBox22.Name = "textBox22";
            textBox22.Size = new Size(56, 29);
            textBox22.TabIndex = 10;
            textBox22.Visible = false;
            // 
            // domainUpDownKK
            // 
            domainUpDownKK.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            domainUpDownKK.Items.Add("K1");
            domainUpDownKK.Items.Add("K2");
            domainUpDownKK.Items.Add("K3");
            domainUpDownKK.Items.Add("K4");
            domainUpDownKK.Location = new Point(265, 140);
            domainUpDownKK.Name = "domainUpDownKK";
            domainUpDownKK.Size = new Size(53, 29);
            domainUpDownKK.TabIndex = 9;
            domainUpDownKK.Text = "-";
            domainUpDownKK.Visible = false;
            domainUpDownKK.Wrap = true;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label9.Location = new Point(19, 419);
            label9.Name = "label9";
            label9.Size = new Size(589, 21);
            label9.TabIndex = 8;
            label9.Text = "Выделите ячейку с наилучшим выбором в таблице и нажмите кнопку проверки.";
            label9.Visible = false;
            // 
            // buttonMode21
            // 
            buttonMode21.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            buttonMode21.Location = new Point(610, 387);
            buttonMode21.Name = "buttonMode21";
            buttonMode21.Size = new Size(99, 30);
            buttonMode21.TabIndex = 7;
            buttonMode21.Text = "Проверить";
            buttonMode21.UseVisualStyleBackColor = true;
            buttonMode21.Visible = false;
            buttonMode21.Click += buttonMode21_Click;
            // 
            // domainUpDownMM
            // 
            domainUpDownMM.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            domainUpDownMM.Items.Add("min");
            domainUpDownMM.Items.Add("max");
            domainUpDownMM.Location = new Point(533, 387);
            domainUpDownMM.Name = "domainUpDownMM";
            domainUpDownMM.Size = new Size(53, 29);
            domainUpDownMM.TabIndex = 6;
            domainUpDownMM.Text = "-";
            domainUpDownMM.Visible = false;
            domainUpDownMM.Wrap = true;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label8.Location = new Point(19, 389);
            label8.Name = "label8";
            label8.Size = new Size(511, 21);
            label8.TabIndex = 5;
            label8.Text = "Задача оптимизации по самому важному критерию имеет вид: К4 → ";
            label8.Visible = false;
            // 
            // labelAlg2
            // 
            labelAlg2.AutoSize = true;
            labelAlg2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            labelAlg2.Location = new Point(3, 358);
            labelAlg2.Name = "labelAlg2";
            labelAlg2.Size = new Size(402, 21);
            labelAlg2.TabIndex = 4;
            labelAlg2.Text = "2) Поиск оптимального решения по 1-му критерию";
            labelAlg2.Visible = false;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label7.Location = new Point(19, 326);
            label7.Name = "label7";
            label7.Size = new Size(645, 21);
            label7.TabIndex = 3;
            label7.Text = "Заполните в таблице строку \"Ранг\" числами от 1 до 4, где \"1\" - самый важный критерий.";
            // 
            // pictureBoxGist
            // 
            pictureBoxGist.Image = (Image)resources.GetObject("pictureBoxGist.Image");
            pictureBoxGist.Location = new Point(210, 60);
            pictureBoxGist.Name = "pictureBoxGist";
            pictureBoxGist.Size = new Size(875, 263);
            pictureBoxGist.SizeMode = PictureBoxSizeMode.AutoSize;
            pictureBoxGist.TabIndex = 2;
            pictureBoxGist.TabStop = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(19, 29);
            label6.Name = "label6";
            label6.Size = new Size(742, 21);
            label6.TabIndex = 1;
            label6.Text = "Приведены результаты оценки значимости критериев тремя группами экспертов в виде гистограмм: ";
            // 
            // labelAlg
            // 
            labelAlg.AutoSize = true;
            labelAlg.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            labelAlg.Location = new Point(3, 0);
            labelAlg.Name = "labelAlg";
            labelAlg.Size = new Size(407, 21);
            labelAlg.TabIndex = 0;
            labelAlg.Text = "1) Ранжирование критериев по степени значимости";
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label24.Location = new Point(19, 302);
            label24.Name = "label24";
            label24.Size = new Size(609, 21);
            label24.TabIndex = 15;
            label24.Text = "Поставленная задача имеет вид:                  →                  , при K1 ∈ [               ;               ]";
            label24.Visible = false;
            // 
            // buttonCheckM
            // 
            buttonCheckM.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            buttonCheckM.Location = new Point(1062, 228);
            buttonCheckM.Name = "buttonCheckM";
            buttonCheckM.Size = new Size(102, 31);
            buttonCheckM.TabIndex = 11;
            buttonCheckM.Text = "Проверить";
            buttonCheckM.UseVisualStyleBackColor = true;
            buttonCheckM.Visible = false;
            buttonCheckM.Click += buttonCheckM_Click;
            // 
            // panelMode3
            // 
            panelMode3.Controls.Add(radioButton10);
            panelMode3.Controls.Add(radioButton9);
            panelMode3.Controls.Add(radioButton8);
            panelMode3.Controls.Add(radioButton7);
            panelMode3.Controls.Add(label29);
            panelMode3.Controls.Add(label27);
            panelMode3.Controls.Add(label13);
            panelMode3.Controls.Add(MatrixNorm);
            panelMode3.Controls.Add(label12);
            panelMode3.Controls.Add(button3Check);
            panelMode3.Controls.Add(domainUpDownPM2);
            panelMode3.Controls.Add(comboBoxNorm3);
            panelMode3.Controls.Add(comboBoxNorm4);
            panelMode3.Controls.Add(domainUpDownPM1);
            panelMode3.Controls.Add(comboBoxNorm2);
            panelMode3.Controls.Add(comboBoxNorm1);
            panelMode3.Controls.Add(label10);
            panelMode3.Controls.Add(label11);
            panelMode3.Location = new Point(33, 331);
            panelMode3.Name = "panelMode3";
            panelMode3.Size = new Size(1275, 492);
            panelMode3.TabIndex = 12;
            // 
            // radioButton10
            // 
            radioButton10.AutoSize = true;
            radioButton10.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            radioButton10.Location = new Point(923, 380);
            radioButton10.Name = "radioButton10";
            radioButton10.Size = new Size(47, 25);
            radioButton10.TabIndex = 26;
            radioButton10.TabStop = true;
            radioButton10.Text = "А4";
            radioButton10.UseVisualStyleBackColor = true;
            radioButton10.Visible = false;
            // 
            // radioButton9
            // 
            radioButton9.AutoSize = true;
            radioButton9.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            radioButton9.Location = new Point(861, 380);
            radioButton9.Name = "radioButton9";
            radioButton9.Size = new Size(47, 25);
            radioButton9.TabIndex = 25;
            radioButton9.TabStop = true;
            radioButton9.Text = "А3";
            radioButton9.UseVisualStyleBackColor = true;
            radioButton9.Visible = false;
            // 
            // radioButton8
            // 
            radioButton8.AutoSize = true;
            radioButton8.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            radioButton8.Location = new Point(802, 380);
            radioButton8.Name = "radioButton8";
            radioButton8.Size = new Size(47, 25);
            radioButton8.TabIndex = 24;
            radioButton8.TabStop = true;
            radioButton8.Text = "А2";
            radioButton8.UseVisualStyleBackColor = true;
            radioButton8.Visible = false;
            // 
            // radioButton7
            // 
            radioButton7.AutoSize = true;
            radioButton7.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            radioButton7.Location = new Point(750, 380);
            radioButton7.Name = "radioButton7";
            radioButton7.Size = new Size(47, 25);
            radioButton7.TabIndex = 23;
            radioButton7.TabStop = true;
            radioButton7.Text = "А1";
            radioButton7.UseVisualStyleBackColor = true;
            radioButton7.Visible = false;
            // 
            // label29
            // 
            label29.AutoSize = true;
            label29.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            label29.Location = new Point(109, 445);
            label29.Name = "label29";
            label29.Size = new Size(1046, 25);
            label29.TabIndex = 22;
            label29.Text = "Результат: при решении поставленной задачи методом главного критерия наилучшей является альтернатива ";
            label29.Visible = false;
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label27.Location = new Point(7, 8);
            label27.Name = "label27";
            label27.Size = new Size(1050, 21);
            label27.TabIndex = 10;
            label27.Text = "Необходимо привести все критерии к эквивалентному состоянию (максимизировать). Измените данные в таблице и нажмите кнопку проверки.\r\n";
            // 
            // label13
            // 
            label13.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label13.Location = new Point(7, 320);
            label13.Name = "label13";
            label13.Size = new Size(963, 112);
            label13.TabIndex = 15;
            label13.Text = resources.GetString("label13.Text");
            label13.Visible = false;
            // 
            // MatrixNorm
            // 
            MatrixNorm.AllowUserToAddRows = false;
            MatrixNorm.AllowUserToDeleteRows = false;
            MatrixNorm.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            MatrixNorm.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = SystemColors.Control;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.True;
            MatrixNorm.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            MatrixNorm.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            MatrixNorm.Columns.AddRange(new DataGridViewColumn[] { dataGridViewTextBoxColumn1, dataGridViewTextBoxColumn2, dataGridViewTextBoxColumn3, dataGridViewTextBoxColumn4, dataGridViewTextBoxColumn5 });
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = SystemColors.Window;
            dataGridViewCellStyle4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle4.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.False;
            MatrixNorm.DefaultCellStyle = dataGridViewCellStyle4;
            MatrixNorm.Location = new Point(336, 178);
            MatrixNorm.Name = "MatrixNorm";
            MatrixNorm.ReadOnly = true;
            MatrixNorm.RowTemplate.Height = 25;
            MatrixNorm.Size = new Size(668, 132);
            MatrixNorm.TabIndex = 14;
            MatrixNorm.Visible = false;
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewTextBoxColumn1.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            dataGridViewTextBoxColumn1.HeaderText = "Альтернативы/критерии";
            dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            dataGridViewTextBoxColumn1.ReadOnly = true;
            dataGridViewTextBoxColumn1.Width = 211;
            // 
            // dataGridViewTextBoxColumn2
            // 
            dataGridViewTextBoxColumn2.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            dataGridViewTextBoxColumn2.HeaderText = "Цена";
            dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            dataGridViewTextBoxColumn2.ReadOnly = true;
            dataGridViewTextBoxColumn2.Width = 72;
            // 
            // dataGridViewTextBoxColumn3
            // 
            dataGridViewTextBoxColumn3.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            dataGridViewTextBoxColumn3.HeaderText = "Площадь";
            dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            dataGridViewTextBoxColumn3.ReadOnly = true;
            dataGridViewTextBoxColumn3.Width = 101;
            // 
            // dataGridViewTextBoxColumn4
            // 
            dataGridViewTextBoxColumn4.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            dataGridViewTextBoxColumn4.HeaderText = "Расположение";
            dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            dataGridViewTextBoxColumn4.ReadOnly = true;
            dataGridViewTextBoxColumn4.Width = 140;
            // 
            // dataGridViewTextBoxColumn5
            // 
            dataGridViewTextBoxColumn5.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            dataGridViewTextBoxColumn5.HeaderText = "Качество";
            dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            dataGridViewTextBoxColumn5.ReadOnly = true;
            // 
            // label12
            // 
            label12.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label12.Location = new Point(470, 79);
            label12.Name = "label12";
            label12.Size = new Size(800, 86);
            label12.TabIndex = 13;
            label12.Text = resources.GetString("label12.Text");
            label12.Visible = false;
            // 
            // button3Check
            // 
            button3Check.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            button3Check.Location = new Point(511, 95);
            button3Check.Name = "button3Check";
            button3Check.Size = new Size(112, 32);
            button3Check.TabIndex = 12;
            button3Check.Text = "Проверить";
            button3Check.UseVisualStyleBackColor = true;
            button3Check.Visible = false;
            button3Check.Click += button3Check_Click;
            // 
            // domainUpDownPM2
            // 
            domainUpDownPM2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            domainUpDownPM2.Items.Add("-");
            domainUpDownPM2.Items.Add("+");
            domainUpDownPM2.Items.Add("/");
            domainUpDownPM2.Items.Add("*");
            domainUpDownPM2.Location = new Point(272, 123);
            domainUpDownPM2.Name = "domainUpDownPM2";
            domainUpDownPM2.Size = new Size(37, 29);
            domainUpDownPM2.TabIndex = 11;
            domainUpDownPM2.Text = "-";
            domainUpDownPM2.Visible = false;
            // 
            // comboBoxNorm3
            // 
            comboBoxNorm3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            comboBoxNorm3.FormattingEnabled = true;
            comboBoxNorm3.Items.AddRange(new object[] { "K[n](A[i])", "min(K[n](A[i]))", "max(K[n](A[i]))" });
            comboBoxNorm3.Location = new Point(134, 123);
            comboBoxNorm3.Name = "comboBoxNorm3";
            comboBoxNorm3.Size = new Size(132, 29);
            comboBoxNorm3.TabIndex = 10;
            comboBoxNorm3.Visible = false;
            // 
            // comboBoxNorm4
            // 
            comboBoxNorm4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            comboBoxNorm4.FormattingEnabled = true;
            comboBoxNorm4.Items.AddRange(new object[] { "K[n](A[i])", "min(K[n](A[i]))", "max(K[n](A[i]))" });
            comboBoxNorm4.Location = new Point(315, 123);
            comboBoxNorm4.Name = "comboBoxNorm4";
            comboBoxNorm4.Size = new Size(132, 29);
            comboBoxNorm4.TabIndex = 9;
            comboBoxNorm4.Visible = false;
            // 
            // domainUpDownPM1
            // 
            domainUpDownPM1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            domainUpDownPM1.Items.Add("-");
            domainUpDownPM1.Items.Add("+");
            domainUpDownPM1.Items.Add("/");
            domainUpDownPM1.Items.Add("*");
            domainUpDownPM1.Location = new Point(272, 83);
            domainUpDownPM1.Name = "domainUpDownPM1";
            domainUpDownPM1.Size = new Size(37, 29);
            domainUpDownPM1.TabIndex = 8;
            domainUpDownPM1.Text = "-";
            domainUpDownPM1.Visible = false;
            // 
            // comboBoxNorm2
            // 
            comboBoxNorm2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            comboBoxNorm2.FormattingEnabled = true;
            comboBoxNorm2.Items.AddRange(new object[] { "K[n](A[i])", "min(K[n](A[i]))", "max(K[n](A[i]))" });
            comboBoxNorm2.Location = new Point(315, 83);
            comboBoxNorm2.Name = "comboBoxNorm2";
            comboBoxNorm2.Size = new Size(132, 29);
            comboBoxNorm2.TabIndex = 7;
            comboBoxNorm2.Visible = false;
            // 
            // comboBoxNorm1
            // 
            comboBoxNorm1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            comboBoxNorm1.FormattingEnabled = true;
            comboBoxNorm1.Items.AddRange(new object[] { "K[n](A[i])", "min(K[n](A[i]))", "max(K[n](A[i]))" });
            comboBoxNorm1.Location = new Point(134, 83);
            comboBoxNorm1.Name = "comboBoxNorm1";
            comboBoxNorm1.Size = new Size(132, 29);
            comboBoxNorm1.TabIndex = 2;
            comboBoxNorm1.Visible = false;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label10.Location = new Point(7, 38);
            label10.Name = "label10";
            label10.Size = new Size(822, 21);
            label10.TabIndex = 1;
            label10.Text = "Для приведения критериев к сопоставимому виду и обеспечения их эквивалентности используется нормировка:";
            label10.Visible = false;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label11.Location = new Point(7, 101);
            label11.Name = "label11";
            label11.Size = new Size(451, 21);
            label11.TabIndex = 6;
            label11.Text = "Knorm[n](A[i]) = ______________________________________________";
            label11.Visible = false;
            // 
            // panelMode4
            // 
            panelMode4.Controls.Add(label18);
            panelMode4.Controls.Add(groupBox1);
            panelMode4.Controls.Add(textBoxF4);
            panelMode4.Controls.Add(textBoxF3);
            panelMode4.Controls.Add(textBoxF2);
            panelMode4.Controls.Add(textBoxF1);
            panelMode4.Controls.Add(domainUpDownF);
            panelMode4.Controls.Add(MatrixNorm2);
            panelMode4.Controls.Add(label15);
            panelMode4.Controls.Add(radioButtonAdd);
            panelMode4.Controls.Add(radioButtonExtr);
            panelMode4.Controls.Add(pictureBoxAdd);
            panelMode4.Controls.Add(pictureBoxExtr);
            panelMode4.Controls.Add(pictureBoxMult);
            panelMode4.Controls.Add(radioButtonMult);
            panelMode4.Controls.Add(label14);
            panelMode4.Controls.Add(button4Check);
            panelMode4.Controls.Add(label4Title);
            panelMode4.Controls.Add(label16);
            panelMode4.Location = new Point(12, 302);
            panelMode4.Name = "panelMode4";
            panelMode4.Size = new Size(1296, 504);
            panelMode4.TabIndex = 16;
            panelMode4.Visible = false;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            label18.Location = new Point(114, 459);
            label18.Name = "label18";
            label18.Size = new Size(1062, 25);
            label18.TabIndex = 69;
            label18.Text = "Результат: при решении поставленной задачи методом аддитивной свертки наилучшей является альтернатива ";
            label18.Visible = false;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(radioButton14);
            groupBox1.Controls.Add(radioButton12);
            groupBox1.Controls.Add(radioButton13);
            groupBox1.Controls.Add(radioButton11);
            groupBox1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            groupBox1.Location = new Point(1038, 342);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(272, 57);
            groupBox1.TabIndex = 68;
            groupBox1.TabStop = false;
            groupBox1.Text = "Выберете лучшую альтернативу:";
            groupBox1.Visible = false;
            // 
            // radioButton14
            // 
            radioButton14.AutoSize = true;
            radioButton14.Location = new Point(211, 24);
            radioButton14.Name = "radioButton14";
            radioButton14.Size = new Size(47, 25);
            radioButton14.TabIndex = 2;
            radioButton14.TabStop = true;
            radioButton14.Text = "А4";
            radioButton14.UseVisualStyleBackColor = true;
            // 
            // radioButton12
            // 
            radioButton12.AutoSize = true;
            radioButton12.Location = new Point(73, 24);
            radioButton12.Name = "radioButton12";
            radioButton12.Size = new Size(47, 25);
            radioButton12.TabIndex = 1;
            radioButton12.TabStop = true;
            radioButton12.Text = "А2";
            radioButton12.UseVisualStyleBackColor = true;
            // 
            // radioButton13
            // 
            radioButton13.AutoSize = true;
            radioButton13.Location = new Point(142, 24);
            radioButton13.Name = "radioButton13";
            radioButton13.Size = new Size(47, 25);
            radioButton13.TabIndex = 1;
            radioButton13.TabStop = true;
            radioButton13.Text = "А3";
            radioButton13.UseVisualStyleBackColor = true;
            // 
            // radioButton11
            // 
            radioButton11.AutoSize = true;
            radioButton11.Location = new Point(6, 24);
            radioButton11.Name = "radioButton11";
            radioButton11.Size = new Size(47, 25);
            radioButton11.TabIndex = 0;
            radioButton11.TabStop = true;
            radioButton11.Text = "А1";
            radioButton11.UseVisualStyleBackColor = true;
            // 
            // textBoxF4
            // 
            textBoxF4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBoxF4.Location = new Point(718, 405);
            textBoxF4.Name = "textBoxF4";
            textBoxF4.Size = new Size(55, 29);
            textBoxF4.TabIndex = 67;
            textBoxF4.Visible = false;
            // 
            // textBoxF3
            // 
            textBoxF3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBoxF3.Location = new Point(634, 405);
            textBoxF3.Name = "textBoxF3";
            textBoxF3.Size = new Size(55, 29);
            textBoxF3.TabIndex = 66;
            textBoxF3.Visible = false;
            // 
            // textBoxF2
            // 
            textBoxF2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBoxF2.Location = new Point(547, 405);
            textBoxF2.Name = "textBoxF2";
            textBoxF2.Size = new Size(55, 29);
            textBoxF2.TabIndex = 65;
            textBoxF2.Visible = false;
            // 
            // textBoxF1
            // 
            textBoxF1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBoxF1.Location = new Point(460, 404);
            textBoxF1.Name = "textBoxF1";
            textBoxF1.Size = new Size(55, 29);
            textBoxF1.TabIndex = 63;
            textBoxF1.Visible = false;
            // 
            // domainUpDownF
            // 
            domainUpDownF.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            domainUpDownF.Items.Add("min");
            domainUpDownF.Items.Add("max");
            domainUpDownF.Location = new Point(823, 405);
            domainUpDownF.Name = "domainUpDownF";
            domainUpDownF.Size = new Size(53, 29);
            domainUpDownF.TabIndex = 62;
            domainUpDownF.Text = "-";
            domainUpDownF.Visible = false;
            domainUpDownF.Wrap = true;
            // 
            // MatrixNorm2
            // 
            MatrixNorm2.AllowUserToAddRows = false;
            MatrixNorm2.AllowUserToDeleteRows = false;
            MatrixNorm2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            MatrixNorm2.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = SystemColors.Control;
            dataGridViewCellStyle5.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle5.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = DataGridViewTriState.True;
            MatrixNorm2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            MatrixNorm2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            MatrixNorm2.Columns.AddRange(new DataGridViewColumn[] { dataGridViewTextBoxColumn6, dataGridViewTextBoxColumn7, dataGridViewTextBoxColumn8, dataGridViewTextBoxColumn9, dataGridViewTextBoxColumn10 });
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = SystemColors.Window;
            dataGridViewCellStyle6.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle6.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle6.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.False;
            MatrixNorm2.DefaultCellStyle = dataGridViewCellStyle6;
            MatrixNorm2.Location = new Point(364, 264);
            MatrixNorm2.Name = "MatrixNorm2";
            MatrixNorm2.ReadOnly = true;
            MatrixNorm2.RowTemplate.Height = 25;
            MatrixNorm2.Size = new Size(668, 132);
            MatrixNorm2.TabIndex = 60;
            MatrixNorm2.Visible = false;
            // 
            // dataGridViewTextBoxColumn6
            // 
            dataGridViewTextBoxColumn6.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            dataGridViewTextBoxColumn6.HeaderText = "Альтернативы/критерии";
            dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            dataGridViewTextBoxColumn6.ReadOnly = true;
            dataGridViewTextBoxColumn6.Width = 211;
            // 
            // dataGridViewTextBoxColumn7
            // 
            dataGridViewTextBoxColumn7.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            dataGridViewTextBoxColumn7.HeaderText = "Цена";
            dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            dataGridViewTextBoxColumn7.ReadOnly = true;
            dataGridViewTextBoxColumn7.Width = 72;
            // 
            // dataGridViewTextBoxColumn8
            // 
            dataGridViewTextBoxColumn8.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            dataGridViewTextBoxColumn8.HeaderText = "Площадь";
            dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            dataGridViewTextBoxColumn8.ReadOnly = true;
            dataGridViewTextBoxColumn8.Width = 101;
            // 
            // dataGridViewTextBoxColumn9
            // 
            dataGridViewTextBoxColumn9.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            dataGridViewTextBoxColumn9.HeaderText = "Расположение";
            dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            dataGridViewTextBoxColumn9.ReadOnly = true;
            dataGridViewTextBoxColumn9.Width = 140;
            // 
            // dataGridViewTextBoxColumn10
            // 
            dataGridViewTextBoxColumn10.AutoSizeMode = DataGridViewAutoSizeColumnMode.ColumnHeader;
            dataGridViewTextBoxColumn10.HeaderText = "Качество";
            dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            dataGridViewTextBoxColumn10.ReadOnly = true;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label15.Location = new Point(7, 191);
            label15.Name = "label15";
            label15.Size = new Size(1293, 63);
            label15.TabIndex = 9;
            label15.Text = resources.GetString("label15.Text");
            label15.Visible = false;
            // 
            // radioButtonAdd
            // 
            radioButtonAdd.AutoSize = true;
            radioButtonAdd.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            radioButtonAdd.Location = new Point(484, 160);
            radioButtonAdd.Name = "radioButtonAdd";
            radioButtonAdd.Size = new Size(14, 13);
            radioButtonAdd.TabIndex = 8;
            radioButtonAdd.TabStop = true;
            radioButtonAdd.UseVisualStyleBackColor = true;
            // 
            // radioButtonExtr
            // 
            radioButtonExtr.AutoSize = true;
            radioButtonExtr.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            radioButtonExtr.Location = new Point(484, 109);
            radioButtonExtr.Name = "radioButtonExtr";
            radioButtonExtr.Size = new Size(14, 13);
            radioButtonExtr.TabIndex = 7;
            radioButtonExtr.TabStop = true;
            radioButtonExtr.UseVisualStyleBackColor = true;
            // 
            // pictureBoxAdd
            // 
            pictureBoxAdd.Image = Properties.Resources.Add;
            pictureBoxAdd.Location = new Point(507, 148);
            pictureBoxAdd.Name = "pictureBoxAdd";
            pictureBoxAdd.Size = new Size(194, 41);
            pictureBoxAdd.TabIndex = 6;
            pictureBoxAdd.TabStop = false;
            // 
            // pictureBoxExtr
            // 
            pictureBoxExtr.Image = Properties.Resources.Extr;
            pictureBoxExtr.Location = new Point(507, 94);
            pictureBoxExtr.Name = "pictureBoxExtr";
            pictureBoxExtr.Size = new Size(207, 41);
            pictureBoxExtr.TabIndex = 5;
            pictureBoxExtr.TabStop = false;
            // 
            // pictureBoxMult
            // 
            pictureBoxMult.Image = Properties.Resources.Mult;
            pictureBoxMult.Location = new Point(507, 43);
            pictureBoxMult.Name = "pictureBoxMult";
            pictureBoxMult.Size = new Size(194, 39);
            pictureBoxMult.TabIndex = 4;
            pictureBoxMult.TabStop = false;
            // 
            // radioButtonMult
            // 
            radioButtonMult.AutoSize = true;
            radioButtonMult.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            radioButtonMult.Location = new Point(484, 56);
            radioButtonMult.Name = "radioButtonMult";
            radioButtonMult.Size = new Size(14, 13);
            radioButtonMult.TabIndex = 3;
            radioButtonMult.TabStop = true;
            radioButtonMult.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label14.Location = new Point(7, 46);
            label14.Name = "label14";
            label14.Size = new Size(399, 21);
            label14.TabIndex = 2;
            label14.Text = "При аддитивной свертке суперкритерий строится как:";
            // 
            // button4Check
            // 
            button4Check.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            button4Check.Location = new Point(784, 99);
            button4Check.Name = "button4Check";
            button4Check.Size = new Size(111, 29);
            button4Check.TabIndex = 1;
            button4Check.Text = "Проверить";
            button4Check.UseVisualStyleBackColor = true;
            button4Check.Click += button4Check_Click;
            // 
            // label4Title
            // 
            label4Title.AutoSize = true;
            label4Title.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            label4Title.Location = new Point(563, 1);
            label4Title.Name = "label4Title";
            label4Title.Size = new Size(187, 25);
            label4Title.TabIndex = 0;
            label4Title.Text = "Аддитивная свертка";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label16.Location = new Point(17, 407);
            label16.Name = "label16";
            label16.Size = new Size(801, 21);
            label16.TabIndex = 61;
            label16.Text = "Тогда суперкритерий с учетом весовых коэффициентов:  K =               x1+               x2+               x3+               x4 →\r\n";
            label16.Visible = false;
            // 
            // panelMode5
            // 
            panelMode5.Controls.Add(label20);
            panelMode5.Controls.Add(label17);
            panelMode5.Controls.Add(dataGridView1);
            panelMode5.Controls.Add(button2);
            panelMode5.Controls.Add(label19);
            panelMode5.Location = new Point(12, 290);
            panelMode5.Name = "panelMode5";
            panelMode5.Size = new Size(1377, 516);
            panelMode5.TabIndex = 17;
            panelMode5.Visible = false;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label20.Location = new Point(509, 329);
            label20.Name = "label20";
            label20.Size = new Size(225, 25);
            label20.TabIndex = 6;
            label20.Text = "Рекомендуемая оценка: ";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label17.Location = new Point(509, 273);
            label17.Name = "label17";
            label17.Size = new Size(361, 25);
            label17.TabIndex = 5;
            label17.Text = "Количество допущенных ошибок из 21: ";
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCellsExceptHeaders;
            dataGridViewCellStyle7.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = SystemColors.Control;
            dataGridViewCellStyle7.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle7.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = DataGridViewTriState.True;
            dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { dataGridViewTextBoxColumn11, dataGridViewTextBoxColumn12 });
            dataGridViewCellStyle8.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = SystemColors.Window;
            dataGridViewCellStyle8.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle8.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = DataGridViewTriState.False;
            dataGridView1.DefaultCellStyle = dataGridViewCellStyle8;
            dataGridView1.EditMode = DataGridViewEditMode.EditOnEnter;
            dataGridView1.Location = new Point(387, 92);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(615, 132);
            dataGridView1.TabIndex = 4;
            // 
            // dataGridViewTextBoxColumn11
            // 
            dataGridViewTextBoxColumn11.AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            dataGridViewTextBoxColumn11.FillWeight = 194.923859F;
            dataGridViewTextBoxColumn11.HeaderText = "Название метода";
            dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            dataGridViewTextBoxColumn11.ReadOnly = true;
            dataGridViewTextBoxColumn11.Width = 350;
            // 
            // dataGridViewTextBoxColumn12
            // 
            dataGridViewTextBoxColumn12.AutoSizeMode = DataGridViewAutoSizeColumnMode.None;
            dataGridViewTextBoxColumn12.FillWeight = 5.07614136F;
            dataGridViewTextBoxColumn12.HeaderText = "Наилучшая альтернатива";
            dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            dataGridViewTextBoxColumn12.ReadOnly = true;
            dataGridViewTextBoxColumn12.Width = 220;
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            button2.Location = new Point(620, 452);
            button2.Name = "button2";
            button2.Size = new Size(165, 32);
            button2.TabIndex = 1;
            button2.Text = "Вернуться в меню";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label19.Location = new Point(241, 27);
            label19.Name = "label19";
            label19.Size = new Size(890, 25);
            label19.TabIndex = 0;
            label19.Text = "     В результате выполнения лабораторной работы получены следующие наилучшие альтернативы:\r\n";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.InitialImage = null;
            pictureBox1.Location = new Point(12, 12);
            pictureBox1.Margin = new Padding(4, 3, 4, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(27, 27);
            pictureBox1.TabIndex = 18;
            pictureBox1.TabStop = false;
            toolTip1.SetToolTip(pictureBox1, resources.GetString("pictureBox1.ToolTip"));
            pictureBox1.Visible = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.InitialImage = null;
            pictureBox2.Location = new Point(12, 12);
            pictureBox2.Margin = new Padding(4, 3, 4, 3);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(27, 27);
            pictureBox2.TabIndex = 19;
            pictureBox2.TabStop = false;
            toolTip1.SetToolTip(pictureBox2, resources.GetString("pictureBox2.ToolTip"));
            pictureBox2.Visible = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.InitialImage = null;
            pictureBox3.Location = new Point(12, 12);
            pictureBox3.Margin = new Padding(4, 3, 4, 3);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(27, 27);
            pictureBox3.TabIndex = 20;
            pictureBox3.TabStop = false;
            toolTip1.SetToolTip(pictureBox3, resources.GetString("pictureBox3.ToolTip"));
            pictureBox3.Visible = false;
            // 
            // Lab
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.GhostWhite;
            ClientSize = new Size(1401, 818);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(buttonCheckM);
            Controls.Add(Matrix);
            Controls.Add(textBox1);
            Controls.Add(Title1);
            Controls.Add(buttonNext2);
            Controls.Add(panelMode5);
            Controls.Add(panelMode1);
            Controls.Add(panelMode2);
            Controls.Add(panelMode4);
            Controls.Add(panelMode3);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Lab";
            Text = "Лабораторная работа";
            ((System.ComponentModel.ISupportInitialize)Matrix).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panelMode1.ResumeLayout(false);
            panelMode1.PerformLayout();
            panelMode2.ResumeLayout(false);
            panelMode2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxGist).EndInit();
            panelMode3.ResumeLayout(false);
            panelMode3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)MatrixNorm).EndInit();
            panelMode4.ResumeLayout(false);
            panelMode4.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)MatrixNorm2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxAdd).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxExtr).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBoxMult).EndInit();
            panelMode5.ResumeLayout(false);
            panelMode5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label Title1;
        private TextBox textBox1;
        private DataGridView Matrix;
        private DataGridViewTextBoxColumn AK;
        private DataGridViewTextBoxColumn K1;
        private DataGridViewTextBoxColumn K2;
        private DataGridViewTextBoxColumn K3;
        private DataGridViewTextBoxColumn K4;
        private Label labelQ1;
        private DomainUpDown domainUpDown1;
        private Panel panel1;
        private TextBox text2;
        private Label labelT1;
        private Button buttonNext1;
        private Panel panel2;
        private TextBox system11;
        private Label label1;
        private Button buttonNext2;
        private TextBox system44;
        private TextBox system43;
        private TextBox system42;
        private TextBox system41;
        private Label label3;
        private DomainUpDown domainUpDown4;
        private TextBox system34;
        private TextBox system24;
        private TextBox system33;
        private TextBox system14;
        private TextBox system32;
        private TextBox system23;
        private TextBox system31;
        private TextBox system13;
        private Label label2;
        private DomainUpDown domainUpDown3;
        private TextBox system22;
        private TextBox system12;
        private TextBox system21;
        private Label label5;
        private DomainUpDown domainUpDown2;
        private Panel panelMode1;
        private Panel panelMode2;
        private Label labelAlg;
        private Label label7;
        private PictureBox pictureBoxGist;
        private Label label6;
        private Button buttonCheckM;
        private Button button1;
        private Label label4;
        private Label labelAlg2;
        private DomainUpDown domainUpDownMM;
        private Label label8;
        private Label label9;
        private Button buttonMode21;
        private Panel panelMode3;
        private DomainUpDown domainUpDownKK;
        private Label label10;
        private ComboBox comboBoxNorm1;
        private Label label11;
        private DomainUpDown domainUpDownPM1;
        private ComboBox comboBoxNorm2;
        private DomainUpDown domainUpDownPM2;
        private ComboBox comboBoxNorm3;
        private ComboBox comboBoxNorm4;
        private Button button3Check;
        private DataGridView MatrixNorm;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private Label label12;
        private Label label13;
        private Panel panelMode4;
        private RadioButton radioButton2;
        private RadioButton radioButton1;
        private Label label4Title;
        private Label label15;
        private RadioButton radioButtonAdd;
        private RadioButton radioButtonExtr;
        private PictureBox pictureBoxAdd;
        private PictureBox pictureBoxExtr;
        private PictureBox pictureBoxMult;
        private RadioButton radioButtonMult;
        private Label label14;
        private Button button4Check;
        private TextBox textBox22;
        private TextBox textBox23;
        private Label labelAlg3;
        private Label label22;
        private Label label23;
        private Label label24;
        private Label label26;
        private Label label25;
        private DomainUpDown domainUpDownMM2;
        private TextBox textBox25;
        private TextBox textBox24;
        private DomainUpDown domainUpDownKK2;
        private Label label27;
        private Label label29;
        private DataGridView MatrixNorm2;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private TextBox textBoxF4;
        private TextBox textBoxF3;
        private TextBox textBoxF2;
        private TextBox textBoxF1;
        private DomainUpDown domainUpDownF;
        private Label label16;
        private Label label18;
        private GroupBox groupBox1;
        private RadioButton radioButton14;
        private RadioButton radioButton12;
        private RadioButton radioButton13;
        private RadioButton radioButton11;
        private Panel panelMode5;
        private Button button2;
        private Label label19;
        private PictureBox pictureBox1;
        private ToolTip toolTip1;
        private RadioButton radioButton10;
        private RadioButton radioButton9;
        private RadioButton radioButton8;
        private RadioButton radioButton7;
        private DataGridView dataGridView1;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private Label label20;
        private Label label17;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
    }
}