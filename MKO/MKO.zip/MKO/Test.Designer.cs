﻿namespace MKO
{
    partial class Test
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Test));
            tableLayoutPanel1 = new TableLayoutPanel();
            textBox7 = new TextBox();
            textBox6 = new TextBox();
            textBox8 = new TextBox();
            textBox10 = new TextBox();
            textBox9 = new TextBox();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            textBox3 = new TextBox();
            textBox5 = new TextBox();
            textBox4 = new TextBox();
            labelTest = new Label();
            radioButton1 = new RadioButton();
            groupBox1 = new GroupBox();
            radioButton2 = new RadioButton();
            radioButton3 = new RadioButton();
            button2 = new Button();
            button1 = new Button();
            label1 = new Label();
            label2 = new Label();
            panel1 = new Panel();
            label3 = new Label();
            label5 = new Label();
            tableLayoutPanel1.SuspendLayout();
            groupBox1.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 10;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10F));
            tableLayoutPanel1.Controls.Add(textBox7, 0, 0);
            tableLayoutPanel1.Controls.Add(textBox6, 0, 0);
            tableLayoutPanel1.Controls.Add(textBox8, 0, 0);
            tableLayoutPanel1.Controls.Add(textBox10, 0, 0);
            tableLayoutPanel1.Controls.Add(textBox9, 0, 0);
            tableLayoutPanel1.Controls.Add(textBox2, 0, 0);
            tableLayoutPanel1.Controls.Add(textBox1, 0, 0);
            tableLayoutPanel1.Controls.Add(textBox3, 0, 0);
            tableLayoutPanel1.Controls.Add(textBox5, 0, 0);
            tableLayoutPanel1.Controls.Add(textBox4, 0, 0);
            tableLayoutPanel1.Location = new Point(20, 45);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 1;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.Size = new Size(742, 35);
            tableLayoutPanel1.TabIndex = 0;
            // 
            // textBox7
            // 
            textBox7.BackColor = Color.White;
            textBox7.Enabled = false;
            textBox7.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBox7.Location = new Point(447, 3);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(68, 29);
            textBox7.TabIndex = 9;
            textBox7.Text = "7";
            textBox7.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox6
            // 
            textBox6.BackColor = Color.White;
            textBox6.Enabled = false;
            textBox6.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBox6.Location = new Point(373, 3);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(68, 29);
            textBox6.TabIndex = 8;
            textBox6.Text = "6";
            textBox6.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox8
            // 
            textBox8.BackColor = Color.White;
            textBox8.Enabled = false;
            textBox8.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBox8.Location = new Point(521, 3);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(68, 29);
            textBox8.TabIndex = 7;
            textBox8.Text = "8";
            textBox8.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox10
            // 
            textBox10.BackColor = Color.White;
            textBox10.Enabled = false;
            textBox10.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBox10.Location = new Point(669, 3);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(68, 29);
            textBox10.TabIndex = 6;
            textBox10.Text = "10";
            textBox10.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox9
            // 
            textBox9.BackColor = Color.White;
            textBox9.Enabled = false;
            textBox9.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBox9.Location = new Point(595, 3);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(68, 29);
            textBox9.TabIndex = 5;
            textBox9.Text = "9";
            textBox9.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            textBox2.BackColor = Color.White;
            textBox2.Enabled = false;
            textBox2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBox2.Location = new Point(77, 3);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(68, 29);
            textBox2.TabIndex = 4;
            textBox2.Text = "2";
            textBox2.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox1
            // 
            textBox1.BackColor = Color.White;
            textBox1.Enabled = false;
            textBox1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBox1.Location = new Point(3, 3);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(68, 29);
            textBox1.TabIndex = 3;
            textBox1.Text = "1";
            textBox1.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox3
            // 
            textBox3.BackColor = Color.White;
            textBox3.Enabled = false;
            textBox3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBox3.Location = new Point(151, 3);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(68, 29);
            textBox3.TabIndex = 2;
            textBox3.Text = "3";
            textBox3.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox5
            // 
            textBox5.BackColor = Color.White;
            textBox5.Enabled = false;
            textBox5.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBox5.Location = new Point(299, 3);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(68, 29);
            textBox5.TabIndex = 1;
            textBox5.Text = "5";
            textBox5.TextAlign = HorizontalAlignment.Center;
            // 
            // textBox4
            // 
            textBox4.BackColor = Color.White;
            textBox4.Enabled = false;
            textBox4.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBox4.Location = new Point(225, 3);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(68, 29);
            textBox4.TabIndex = 0;
            textBox4.Text = "4";
            textBox4.TextAlign = HorizontalAlignment.Center;
            // 
            // labelTest
            // 
            labelTest.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            labelTest.AutoSize = true;
            labelTest.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point);
            labelTest.ImageAlign = ContentAlignment.TopCenter;
            labelTest.Location = new Point(319, 9);
            labelTest.Name = "labelTest";
            labelTest.Size = new Size(156, 30);
            labelTest.TabIndex = 1;
            labelTest.Text = "Тестирование";
            labelTest.TextAlign = ContentAlignment.TopCenter;
            // 
            // radioButton1
            // 
            radioButton1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            radioButton1.Location = new Point(19, 28);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(589, 77);
            radioButton1.TabIndex = 2;
            radioButton1.TabStop = true;
            radioButton1.Text = "1";
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(radioButton2);
            groupBox1.Controls.Add(radioButton3);
            groupBox1.Controls.Add(radioButton1);
            groupBox1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            groupBox1.Location = new Point(75, 259);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(628, 280);
            groupBox1.TabIndex = 3;
            groupBox1.TabStop = false;
            groupBox1.Text = "Выберете верный ответ:";
            // 
            // radioButton2
            // 
            radioButton2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            radioButton2.Location = new Point(19, 111);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(589, 76);
            radioButton2.TabIndex = 4;
            radioButton2.TabStop = true;
            radioButton2.Text = "2";
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            radioButton3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            radioButton3.Location = new Point(19, 195);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(589, 73);
            radioButton3.TabIndex = 5;
            radioButton3.TabStop = true;
            radioButton3.Text = "3";
            radioButton3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            button2.Location = new Point(299, 496);
            button2.Name = "button2";
            button2.Size = new Size(204, 33);
            button2.TabIndex = 11;
            button2.Text = "Завершить тестирование";
            button2.UseVisualStyleBackColor = true;
            button2.Visible = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            button1.Location = new Point(651, 545);
            button1.Name = "button1";
            button1.Size = new Size(111, 33);
            button1.TabIndex = 5;
            button1.Text = "Далее";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(19, 52);
            label1.Name = "label1";
            label1.Size = new Size(260, 100);
            label1.TabIndex = 7;
            label1.Text = "Количество верных ответов:\r\n\r\nРекомендуемая оценка:\r\n\r\n";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(287, 52);
            label2.Name = "label2";
            label2.Size = new Size(22, 25);
            label2.TabIndex = 8;
            label2.Text = "9";
            // 
            // panel1
            // 
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(224, 198);
            panel1.Name = "panel1";
            panel1.Size = new Size(336, 231);
            panel1.TabIndex = 9;
            panel1.Visible = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(236, 104);
            label3.Name = "label3";
            label3.Size = new Size(22, 25);
            label3.TabIndex = 9;
            label3.Text = "5";
            // 
            // label5
            // 
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(55, 139);
            label5.Name = "label5";
            label5.Size = new Size(671, 132);
            label5.TabIndex = 10;
            label5.Text = "label5";
            // 
            // Test
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.GhostWhite;
            ClientSize = new Size(788, 590);
            Controls.Add(groupBox1);
            Controls.Add(button2);
            Controls.Add(label5);
            Controls.Add(panel1);
            Controls.Add(button1);
            Controls.Add(labelTest);
            Controls.Add(tableLayoutPanel1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Test";
            Text = "Тестирование";
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            groupBox1.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel1;
        private Label labelTest;
        private RadioButton radioButton1;
        private GroupBox groupBox1;
        private RadioButton radioButton2;
        private RadioButton radioButton3;
        private TextBox textBox4;
        private TextBox textBox7;
        private TextBox textBox6;
        private TextBox textBox8;
        private TextBox textBox10;
        private TextBox textBox9;
        private TextBox textBox2;
        private TextBox textBox1;
        private TextBox textBox3;
        private TextBox textBox5;
        private Button button1;
        private Label label1;
        private Label label2;
        private Panel panel1;
        private Label label3;
        private Label label5;
        private Button button2;
    }
}